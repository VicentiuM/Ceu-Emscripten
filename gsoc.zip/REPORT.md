<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
</head>

<!--
PLEASE REMOVE ALL COMMENTS AFTER READING THEM
-->

<!--
Instructions for the weekly report:
- add a new week to the top every Tuesday night or Wednesday morning
  - the week refers to the past, i.e., from the previous Wednesday morning
    to the Tuesday night that follows
- provide the following information:
  - number of hours spent in the project
  - three small paragraphs (topics + small sentences):
     - what I was supposed to do
     - what I actually did
     - what I will do
-->

-------------------------------------------------------------------------------

# Week-2 (18/05-25/05)

## I worked `10` hours this week (total `10+10`h).

## What I was supposed to do during the past week?

I was supposed to make make it so that what the client writes, the server will put the content in files, compile them with emscripten and send the result back to the client.

## What I actually did the past week?

I ported the client and server on the dreamhost. Made it so that the client receives a js file from the server and displays it's contents.

## What I will do the next week?

Make a main.c file that works with all the ceu examples. Maybe also make it so that the server creates the file.

-------------------------------------------------------------------------------



-------------------------------------------------------------------------------

# Week-1 (11/05-17/05)

## I worked `10` hours this week (total `0+10`h).

## What I was supposed to do during the past week?

I studied how to make a server-client in php

## What I actually did the past week?

I studied and made a basic html client php server that comunicates between them.

## What I will do the next week?

I will make it so that what the client writes, the server will put the content in files, compile them with emscripten and send the result back to the client.

-------------------------------------------------------------------------------

# Week-0 (04/05-10/05)

## I worked `0` hours this week (total `0`h).

## What I was supposed to do during the past week?

Nothing, the project starts tomorrow.

## What I actually did the past week?

Nothing, the project starts tomorrow.

## What I will do the next week?

<!--
// fill with community-bonding related activities
// and whatever you feel like doing...
// below are examples, modify at will
-->

1. Subscribe and write about the project to the mailing list of Céu.
2. Study how the current website works.
3. ???

-------------------------------------------------------------------------------
